from pathlib import Path
import re, sys, struct
root=Path(__file__).resolve().parents[1]
a=root/'app/src/main/assets'
java=(root/'app/src/main/java/br/mvz/mika/MainActivity.java').read_text()
html=(a/'index.html').read_text()
js=(a/'app.js').read_text()
style=(a/'style.css').read_text()
images=set(re.findall(r'(?:src|href)=[\"\']([^\"\']+\.png)[\"\']',html))
images.update(re.findall(r'(?<![\w/])mika-[a-z0-9-]+\.png',js))
images.update(re.findall(r'url\([\"\']?([^\)\"\']+\.png)',style))
assert 'name.matches(\"mika-[a-z0-9-]+\\\\.png\")' in java, 'Android nao permite os PNGs locais'
for name in images:
 path=a/name
 assert path.exists(), f'Asset ausente: {name}'
 if name.endswith('.png'):
  with path.open('rb') as f: header=f.read(24)
  assert header[:8]==b'\x89PNG\r\n\x1a\n',f'PNG invalido: {name}'
  w,h=struct.unpack('>II',header[16:24]);assert w>0 and h>0
 print('OK:',name,'('+str(w)+'x'+str(h)+')')
print('Assets verificados:',len(images))
