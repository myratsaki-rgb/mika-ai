package br.mvz.mika;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceResponse;
import android.webkit.WebResourceRequest;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"mika.local".equals(request.getUrl().getHost()) || !"https".equals(request.getUrl().getScheme());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (!"https".equals(request.getUrl().getScheme()) || !"mika.local".equals(request.getUrl().getHost())) return null;
                String name = request.getUrl().getPath().replaceFirst("^/", "");
                if (!(name.equals("index.html") || name.equals("style.css") || name.equals("app.js") || name.matches("mika-[a-z0-9-]+\\.png"))) return null;
                String mime = name.endsWith(".html") ? "text/html" : (name.endsWith(".css") ? "text/css" : (name.endsWith(".png") ? "image/png" : "application/javascript"));
                try { return new WebResourceResponse(mime, "UTF-8", getAssets().open(name)); }
                catch(Exception e){ return null; }
            }
        });
        web.addJavascriptInterface(new Bridge(), "MikaNative");
        web.loadUrl("https://mika.local/index.html");
        setContentView(web);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private void callback(String reqId, JSONObject result) {
        runOnUiThread(() -> {
            try {
                String js = "window.mikaNativeReply(" + JSONObject.quote(reqId) + "," + result.toString() + ");";
                web.evaluateJavascript(js, null);
            } catch (Exception ignored) { }
        });
    }

    private static boolean allowedEndpoint(String input) throws Exception {
        URI url = new URI(input);
        if (url.getUserInfo() != null || url.getRawQuery() != null || url.getRawFragment() != null) return false;
        String scheme = url.getScheme();
        String host = url.getHost();
        if (scheme == null || host == null || !("https".equals(scheme) || "http".equals(scheme))) return false;
        if (!"http".equals(scheme)) return true;
        // Unencrypted HTTP is allowed ONLY for literal private IPv4 networks; no hostname/DNS rebinding.
        String[] parts = host.split("\\.");
        if (parts.length != 4) return false;
        int[] ip = new int[4];
        for (int i=0;i<4;i++) { ip[i]=Integer.parseInt(parts[i]); if(ip[i]<0 || ip[i]>255) return false; }
        return ip[0]==10 || (ip[0]==172 && ip[1]>=16 && ip[1]<=31) || (ip[0]==192 && ip[1]==168);
    }

    private static JSONObject invoke(String url, String model, String system, String historyJson, boolean isStatus) throws Exception {
        if (!allowedEndpoint(url)) throw new IllegalArgumentException("Use HTTPS ou HTTP com IP privado da sua rede (192.168.x.x, 10.x.x.x ou 172.16–31.x.x).");
        URI parsed = new URI(url);
        if (parsed.getPath() != null && !parsed.getPath().isEmpty() && !"/".equals(parsed.getPath()))
            throw new IllegalArgumentException("Informe apenas o endereço do Ollama, sem caminho extra.");
        String base = url.endsWith("/") ? url.substring(0, url.length()-1) : url;
        URL endpoint = new URL(base + (isStatus ? "/api/tags" : "/api/chat"));
        HttpURLConnection con = (HttpURLConnection) endpoint.openConnection();
        con.setConnectTimeout(8000);
        con.setReadTimeout(isStatus ? 8000 : 180000);
        con.setInstanceFollowRedirects(false);
        con.setRequestMethod(isStatus ? "GET" : "POST");
        con.setRequestProperty("Accept","application/json");
        if (!isStatus) {
            JSONArray messages = new JSONArray(historyJson);
            JSONArray conversation = new JSONArray();
            conversation.put(new JSONObject().put("role","system").put("content",system));
            for (int i=0;i<messages.length();i++) conversation.put(messages.getJSONObject(i));
            JSONObject req = new JSONObject()
                .put("model",model).put("messages",conversation).put("stream",false)
                .put("options",new JSONObject().put("temperature",0.6));
            byte[] bytes = req.toString().getBytes(StandardCharsets.UTF_8);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type","application/json; charset=utf-8");
            con.setFixedLengthStreamingMode(bytes.length);
            try(OutputStream out=con.getOutputStream()){out.write(bytes);}
        }
        int status = con.getResponseCode();
        if (status < 200 || status >= 300) throw new IllegalStateException("Ollama retornou HTTP " + status + ". Confirme o modelo e o servidor.");
        try(InputStream in = con.getInputStream()) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int n;
            while((n=in.read(chunk))!=-1) {
                if(buffer.size()+n>2_000_000) throw new IllegalStateException("Resposta ultrapassou o limite de 2 MB.");
                buffer.write(chunk,0,n);
            }
            JSONObject response = new JSONObject(buffer.toString("UTF-8"));
            if (isStatus) {
                JSONArray models = response.optJSONArray("models");
                boolean found = false;
                if (models != null) for(int i=0;i<models.length();i++){
                    String name = models.getJSONObject(i).optString("name");
                    if (name.equals(model)) found = true;
                }
                return new JSONObject().put("ok",true).put("installed",found);
            }
            String answer = response.optJSONObject("message") == null ? "" : response.getJSONObject("message").optString("content").trim();
            if(answer.isEmpty()) throw new IllegalStateException("O modelo não devolveu texto.");
            return new JSONObject().put("ok",true).put("answer",answer);
        } finally {con.disconnect();}
    }

    public class Bridge {
        @JavascriptInterface public void request(String reqId,String url,String model,String system,String historyJson,String mode){
            new Thread(() -> {
                JSONObject result;
                try {result = invoke(url,model,system,historyJson,"status".equals(mode));}
                catch(Exception e) {
                    String description=e.getMessage()==null?"Falha de conexão.":e.getMessage();
                    result=new JSONObject();
                    try{result.put("ok",false).put("error", description.length()>240?description.substring(0,240):description);}catch(Exception ignored){}
                }
                callback(reqId,result);
            },"MikaNetwork").start();
        }
    }
}
