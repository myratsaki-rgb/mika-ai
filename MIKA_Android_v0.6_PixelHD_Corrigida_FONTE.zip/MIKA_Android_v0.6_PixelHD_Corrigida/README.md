# Mika Pixel HD v0.6 — Correção do carregamento da abertura

## Causa raiz identificada
O Android carregava assets por uma lista permitida dentro do `MainActivity.java`. A imagem `mika-conceito-home.png` estava no ZIP, mas não estava na lista; por isso o WebView exibia seu texto alternativo em vez da ilustração. Agora imagens locais `mika-*.png` são aceitas sem abrir o acesso a domínios externos.

## Outras melhorias
- proporção nativa 1:2 da arte em vez de distorcê-la ou cortá-la;
- corações e brilhos em camadas animadas separadas, sobre a ilustração;
- botão Começar com área de toque real e acessível;
- fallback visual com Mika e botão, caso a arte principal falhe;
- verificador de assets antes da compilação para prevenir regressão;
- identificador `br.mvz.mika.pixelhd.v06` permite instalação paralela à v0.5 para comparar sem apagar os dados antigos.

## Limites
Esta atualização corrige a interface e não incorpora o cérebro offline. A conversa continua dependendo de um modelo Ollama externo. Nenhum APK foi pré-compilado neste pacote.

## Compilação
1. Enviar o ZIP `MIKA_Android_v0.6_PixelHD_Corrigida_FONTE.zip` à raiz do repositório no GitHub.
2. Substituir `compilar-mika-v05.yml` pelo conteúdo de `compilar-mika-v06.yml` (ou adicionar um único workflow v06 e remover workflows antigos).
3. Conferir o build em Actions e baixar o artefato `Mika-PixelHD-v06-APK`.
4. Abrir o APK no Samsung, sem desinstalar v0.5 (a v0.6 é outro aplicativo de teste).

## Teste esperado
Abrir Mika v0.6: você verá o cenário com Mika ao notebook, as plantas e o botão Começar rosa, com corações/brilhos suaves. O botão deve levar ao chat.
