# MIKA IA — Android v0.2 alpha (projeto fonte)

Este pacote contém um projeto Android Studio com a interface da Mika, suas memórias e histórico salvos **no próprio celular**. A interface funciona offline. **A geração de respostas NÃO funciona offline** nesta versão: conecte um Ollama executado por você em computador/servidor local.

## O que está implementado
- Aplicativo Android com WebView nativo, arquivos HTML/CSS/JS empacotados.
- Histórico e memórias persistidos no armazenamento da WebView, separados do protótipo de PC. Memórias duráveis são registradas manualmente.
- Listar/apagar memórias; apagar histórico; copiar backup JSON para área de transferência.
- Configuração de IP e modelo; conexão direta de rede a API Ollama com Android HttpURLConnection, sem web CORS.
- Aviso explícito ao usuário se modelo ausente ou inacessível. Não simula uma resposta de IA.
- Nenhuma chave de serviço comercial exigida.

## O que NÃO está implementado
- Motor LLM dentro do celular; nenhum modelo GGUF/LiteRT incluso.
- Sincronização automática das memórias PC ↔ Android.
- Voz, personagem 3D, execução de ferramentas, geração de vídeos ou autonomia.
- Autenticação de servidor Ollama, interface de permissões ou compartilhamento seguro na internet.

## Como gerar APK (computador)
1. Abra a pasta `MIKA_Android_v0.2` com Android Studio.
2. Aguarde o Gradle baixar o SDK Android 35 e a versão compatível do Android Gradle Plugin.
3. Selecione `Build` > `Build APK(s)`.
4. Localize `app/build/outputs/apk/debug/app-debug.apk` e instale no Android.

## Como gerar APK sem Android Studio (GitHub Actions, mesmo pelo celular)
1. Crie um repositório privado no GitHub e envie **os arquivos desta pasta**, incluindo `.github/workflows/android-apk.yml` (com seu conteúdo completo). Não envie apenas o ZIP.
2. Abra `Actions` > `Compilar APK de teste da Mika` > `Run workflow`.
3. Ao terminar, abra a execução e baixe o artefato `Mika-Android-debug-APK`.
4. Extraia o APK do ZIP do artefato e instale-o.
O GitHub Actions disponibiliza a compilação, mas o APK não está pré-compilado neste pacote. Um APK de debug é apropriado para testes, não publicação na Play Store.

## Como conectar a IA
A versão original Mika IA v0.1 utiliza Ollama em `127.0.0.1` no computador. O IP do computador não pode ser acessado remotamente enquanto a aplicação se limitar a esse endereço. Para usar a API oficial Ollama no seu Wi-Fi, no computador de confiança configure `OLLAMA_HOST=0.0.0.0:11434` e reinicie o serviço Ollama, mantenha o firewall limitado à rede doméstica e nunca faça encaminhamento de porta na internet. **Aviso:** a API Ollama normalmente não possui autenticação por padrão. Use somente rede privada confiável. Abra a Mika no Android, vá a `Conexão`, configure `http://IP-PRIVADO-DO-PC:11434` e o modelo realmente instalado (ex. `qwen3:4b`). O envio de perguntas e memórias recuperadas acontece pela rede até esse servidor, embora a base completa continue no celular.

`http://` é aceito pelo aplicativo apenas para IPs IPv4 privados RFC1918. Para servidores fora da LAN, use HTTPS com autenticação/proxy apropriado (não incluído neste protótipo). O APK não abre nenhum serviço de rede por si só.

## Avisos de privacidade
Dados guardados na WebView não são protegidos por senha própria; mantenha a proteção de tela do aparelho. A operação de limpar dados do app remove o histórico e memórias. Salve backups de forma privada e não compartilhe registros sem revisão. `android:allowBackup=false` impede backup automático Android dos dados do app.

## Projeto original
Este é um protótipo experimental para estudar identidade comportamental, interfaces móveis e independência. A personagem visual oficial ainda precisa ser incorporada a partir de sua prancha canônica, não foi substituída por imagem gerada.

## Próxima fase
Substituir conexão remota por um motor on-device usando o SDK LiteRT-LM ou llama.cpp, com modelo quantizado compatível com a RAM do telefone. Essa integração depende de testes no dispositivo real, licenças e desempenho.
