# MIKA IA v0.7 — Pixel HD Viva (Android)

**Integração do Experimento 004 ao aplicativo Android** — projeto de teste.

## O que está incluído
- Abertura original em pixel art (arte do escritório do conceito aprovado, sem depender de download ou internet).
- Telas do laboratório Pixel HD, com cenário, coração e vaga-lumes animados.
- Mika piscando, deslocando-se até a resposta, pensando, executando, concluindo, agradecendo e se despedindo.
- Sprites retrabalhados com margens transparentes para reduzir cortes em tamanhos menores.
- Memória manual + histórico local no WebView; exportação/importação via JSON no app.
- Conexão opcional ao Ollama em rede privada: configure em Ajustes. Sem Ollama, as respostas são **simulações explicitamente identificadas**, não IA real.
- Android usa WebView com host interno fictício https://mika.local e lista permitida de recursos. Nenhuma biblioteca externa para a interface.
- Package ID separado: `br.mvz.mika.pixelhd.v07` para instalação de teste lado a lado; **memórias de outras versões não são importadas automaticamente**. Faça backup JSON na instalação anterior.

## Compilar sem computador
1. Coloque `MIKA_Android_v0.7_PixelHD_Viva_FONTE.zip` na **raiz** do seu repositório GitHub.
2. Atualize o **workflow já existente** em `.github/workflows/` para o conteúdo do `compilar-mika-v07.yml` entregue separadamente (não crie workflows duplicados).
3. Salve com Commit changes e consulte Actions.
4. Baixe o artefato `Mika-PixelHD-v07-APK` e extraia o `app-debug.apk`.
5. Instale no Android. A v0.7 utiliza ID próprio e pode coexistir com v0.6.

## O que foi testado
- JavaScript: verificação de sintaxe Node.
- Layout e interações: teste em Chromium com viewport 360x780, 320x570 e 1240x820.
- Navegação, splash, chat demonstrativo e cadastro de memória na UI.
- Existência de todos os assets e margens transparentes dos sprites.

## O que ainda precisa validar no Samsung
- Build Android via GitHub Actions: não executado neste ambiente.
- Instalação real, WebView, armazenamento local entre reinicializações e desempenho da animação.
- Conexão de rede real com um Ollama.

## Observações
Não expor o Ollama à internet; restrinja à rede privada. O app não executa LLM local no celular. As reações no modo visual são simuladas em JavaScript para avaliar a experiência.
