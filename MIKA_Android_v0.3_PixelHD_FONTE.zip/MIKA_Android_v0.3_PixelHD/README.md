# MIKA IA — Android v0.3 Pixel HD (alpha)

Um aplicativo Android com interface Pixel HD, protagonista Mika em sprite retrô, memórias locais e conexão configurável com um servidor Ollama privado. O projeto mantém o mesmo `applicationId` da v0.2 e a chave de armazenamento `mika-android-data-v02` para preservar o histórico em atualizações assinadas com a mesma chave.

## O que mudou
- Nova tela inicial interativa em tema Pixel HD com Mika, cenário de escritório, botão Começar.
- Linguagem visual unificada nas telas Início, Conversa, Memórias, Conexão e Projeto.
- Cinco sprites conceituais (idle, happy, thinking, typing, wave), extraídos da folha de pixel art do protótipo autorizado pelo usuário.
- Navegação inferior otimizada para celular e menu lateral para telas maiores.
- Importador de backup JSON de memórias e histórico, compatível com exportação da v0.2.
- Sem dependências web, imagens externas ou bibliotecas JS de terceiros.

## NÃO incluído
- Modelo de IA offline no celular. A conversa depende do Ollama em outro computador/servidor privado.
- Geração de imagem, voz, vídeo, agentes ou automação.
- Sprite canônico definitivo aprovado: os sprites vêm da arte conceitual de teste, não substituem a prancha oficial da Mika.

## Recomendações para instalar em um celular que já tem a v0.2
**ANTES DE QUALQUER DESINSTALAÇÃO:** abra a v0.2, vá a Memórias e use `Copiar backup JSON`. Cole o conteúdo num arquivo .txt privado (ou nota local) e confirme que foi salvo. O JSON contém memórias e histórico pessoais; não compartilhe publicamente.

O GitHub Actions gera APK de debug assinado automaticamente. O certificado de debug pode mudar a cada execução. Se mudar, o Android impedirá a atualização sobre a v0.2 e será necessário desinstalar a antiga — isso pode apagar todos os dados do app. Por isso incluímos restauração em Memórias > Restaurar Backup. Primeiro faça o backup, só depois atualize/desinstale.

Se desejar upgrades futuros preservando dados sem reinstalação, configure assinatura consistente com um keystore privado guardado em secrets de CI (não inclua chaves secretas no repositório). Esta versão não configura assinatura estável.

## Compilar pelo GitHub pelo celular
1. No mesmo repositório privado `mika-ai`, faça upload do arquivo `MIKA_Android_v0.3_PixelHD_FONTE.zip` na raiz.
2. Abra `.github/workflows/compilar-mika.yml` e substitua o conteúdo pelo arquivo externo `compilar-mika-pixelhd.yml` fornecido com a entrega. Só pode haver um workflow do mesmo nome: não é preciso criar dois.
3. Salve em `main`. A ação iniciará automaticamente, ou abra Actions > Compilar APK da Mika — Pixel HD > Run workflow.
4. Após o sinal verde, baixe o artefato `Mika-PixelHD-debug-APK`; extraia o ZIP do artefato e instale o APK.

Um exemplar equivalente de workflow está dentro do projeto em `.github/workflows/android-apk.yml` para uso caso envie a pasta descompactada como repositório raiz.

## Conexão
A tela de Configurações aceita o endereço privado do Ollama, por exemplo `http://192.168.1.100:11434` (endereço real do computador). A API local deve existir e estar acessível na mesma rede. Não abra a API Ollama na internet.

## Código e memória
- UI: `app/src/main/assets/index.html`, `style.css`, `app.js`.
- Ponte Android/Ollama: `app/src/main/java/br/mvz/mika/MainActivity.java`.
- Sprites: `app/src/main/assets/mika-*.png`.
- Guia visual: `DESIGN-SYSTEM-PIXEL-HD.md`.
- Dados do usuário: `localStorage` da WebView, mantidos exclusivamente no telefone; limpar dados do app ou desinstalar poderá apagá-los.

## Testes
Foi validada a sintaxe do JavaScript e a consistência dos arquivos do pacote; **não foi gerado ou instalado um APK neste ambiente**, portanto a compilação final e a apresentação no Samsung ainda precisam ser verificadas no GitHub/telefone.
