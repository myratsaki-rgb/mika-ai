# MIKA IA — Pixel HD Design System v0.3

## Identidade
Direção aprovada pelo usuário: ambiente de jogo retrô em pixel art, com qualidade de leitura e usabilidade de um app HD moderno. A Mika aparece já na abertura, com presença expressiva; a mesma linguagem visual percorre todas as telas.

## Referências
Prancha oficial de Mika (obrigatória antes da aprovação canônica final):
https://drive.google.com/file/d/1SSOa7FljgnVsktW_j3xiyoqhpHeRK_1G/view

Arte conceitual pré-aprovada pelo usuário para testes: folha com entrada de app, expressões e sprites pixelados (arquivo anterior desta conversa). Os sprites dentro de `assets/mika-*.png` foram recortados desse CONCEITO, não da prancha oficial, e ainda não constituem personagem canônica final.

## Padrões visuais
- Sprite pixel art renderizado com `image-rendering: pixelated`, sem suavização que borre pixels.
- Tipografia de interface nítida: sistema operacional no corpo e monoespaçada de inspiração retrô nos títulos e botões. Evitar pixel font minúscula nos parágrafos.
- Paleta base: floresta #092724, verde-petróleo #103b34, verde médio #174b40, creme #fbf1e1, rosa #fa92a6, dourado #e7bf75.
- Contornos sólidos em 2–4 px, sombras com deslocamento duro e superfícies quadradas.
- Animações discretas (respiração, aceno/luz); respeitar a preferência de acessibilidade `prefers-reduced-motion`.
- Alvos touch grandes (>=40 px; recomendação futura 44–48 px) e contrastes altos.
- Componentes: tabbar no celular, drawer lateral e cards com identidade pixel.
- Não transformar o app em videogame: navegação, acessibilidade, informações de conexão e dados devem permanecer claros.

## Telas aplicadas na versão 0.3
1. Início — cenário do escritório construído com CSS, sprite da Mika, mensagem de boas-vindas e botão Começar.
2. Conversar — cabeçalho, personagem, sugestões, balões estilo retrô e composer.
3. Memórias — cadastro, lista, exclusão, exportação, importação de backup.
4. Conexão — configuração e diagnóstico Ollama mantendo aviso de modelo externo.
5. Projeto — milestones, estado real dos recursos e limpeza de histórico.

## Limites
A v0.3 Pixel HD é uma atualização de INTERFACE; não instala nem executa um LLM local no Android. O código não afirma treinamento, multimodalidade nem autonomia. Imagens originais de referência e histórico do usuário não são incluídos no APK, apenas sprites conceituais já aprovados para testes.
