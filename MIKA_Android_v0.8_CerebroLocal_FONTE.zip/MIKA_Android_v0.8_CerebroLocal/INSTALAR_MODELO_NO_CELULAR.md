# Mika IA v0.8 — Primeiro cérebro de IA offline no celular

Este experimento faz a **Mika v0.8 conectar ao llama.cpp instalado no próprio Android** usando Termux. A inferência é local, não usa OpenAI nem Ollama remoto. O motor não está dentro do APK: é um processo separado e precisa ficar aberto.

## Antes de começar — necessário
- Smartphone: Samsung Galaxy A14 5G, Android 14, 4 GB RAM física.
- **Libere idealmente 6–8 GB** de armazenamento. A última medição mostrava 1,7 GB livre; não faça downloads até liberar espaço.
- Tenha Wi-Fi durante a instalação e o download do modelo (depois de pronto, a conversa funciona offline).
- Instale o Termux a partir de **F-Droid** ou do GitHub oficial do Termux; a versão da Play Store pode ter diferenças.

## 1) Instalar o motor (no Termux)
Abra o Termux e execute:

```sh
pkg update && pkg upgrade -y
pkg install llama-cpp curl -y
which llama-server
```

Confirme que o comando `which llama-server` retorna um caminho. Se o pacote não estiver disponível, não prossiga; verifique os repositórios do Termux.

## 2) Baixar o modelo (aprox. 397 MB)

```sh
mkdir -p "$HOME/mika-modelos"
cd "$HOME/mika-modelos"
curl -fL --retry 3 -C - -o Qwen3-0.6B-Q4_K_M.gguf 'https://huggingface.co/unsloth/Qwen3-0.6B-GGUF/resolve/233b3855f89029f46416b3e8fe5970c79b2ad25d/Qwen3-0.6B-Q4_K_M.gguf'
```

Verifique se o arquivo está inteiro (SHA-256 do repositório para a revisão acima):

```sh
echo 'ec691a95ea176bfd9a7839f3347bb5fece084a4665813f6db199ea58ffb53945  Qwen3-0.6B-Q4_K_M.gguf' | sha256sum -c -
```

Se aparecer **FAILED**, não execute o modelo: o arquivo pode estar incompleto.

## 3) Iniciar o cérebro offline

```sh
llama-server -m "$HOME/mika-modelos/Qwen3-0.6B-Q4_K_M.gguf" --host 127.0.0.1 --port 8080 -c 1024 -t 2 -ngl 0
```

O Termux precisa ficar aberto para manter o servidor em funcionamento. O Android pode suspender aplicativos em segundo plano; se o cérebro parar de responder, volte ao Termux e verifique se o processo ainda está rodando.

## 4) Conectar a Mika
- Abra **Mika IA v0.8** → **Ajustes** → **♥ Este celular**.
- Toque em **Testar conexão do cérebro**.
- Se aparecer **Mika offline ativa**, vá para **Chat** e envie: `Oi, Mika. Quem é você?`.
- Você pode desligar o Wi-Fi para comprovar que não há chamada de API externa.

## Expectativas e limites
- O modelo Qwen3-0.6B é pequeno e não equivale à inteligência do ChatGPT; respostas podem ser lentas, curtas e imprecisas.
- A Mika continua com seus sprites, animações, memórias locais e histórico.
- O histórico e as memórias são enviados por HTTP **apenas no loopback** do próprio telefone para o servidor local; eles não saem do aparelho por essa integração.
- O servidor não deve ser exposto à rede Wi-Fi nem à internet. Use somente `--host 127.0.0.1`.
- A v0.8 é um experimento; não é garantia de desempenho em seu A14 até testarmos no aparelho.
- A v0.8 tem outro identificador Android e não lê automaticamente as memórias das versões antigas. Exporte e importe o JSON se quiser recuperar os registros.

## Referências técnicas
- https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
- https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md
- https://huggingface.co/unsloth/Qwen3-0.6B-GGUF/blob/233b3855f89029f46416b3e8fe5970c79b2ad25d/Qwen3-0.6B-Q4_K_M.gguf
