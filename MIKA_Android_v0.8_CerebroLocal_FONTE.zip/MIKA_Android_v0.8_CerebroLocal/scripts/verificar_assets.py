from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
web=root/'app/src/main/assets'
html=(web/'index.html').read_text();css=(web/'style.css').read_text();js=(web/'app.js').read_text()
files={p.name for p in (web/'assets').glob('*.png')}
refs=set(re.findall(r'assets/([a-z0-9-]+\.png)',html+css+js))
missing=refs-files
assert not missing,f'Assets ausentes: {missing}'
assert 'mika-conceito-home.png' in refs
assert 'window.MikaNative.request' in js
print('Mika assets OK:',len(files),'arquivos; ',len(refs),'referencias')
