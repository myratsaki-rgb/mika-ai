# Correção de fidelidade visual — Mika Pixel HD v0.4

**Motivo:** vídeo real do Android mostrou que a versão v0.3 NÃO correspondia ao mockup aprovado. O cenário geométrico era rudimentar; o avatar tinha pouca presença; fonte e cores sozinhas não recriavam o conceito.

## O que foi corrigido
- A splash/home é agora composta pela **arte original integral da tela de referência**, recortada da prancha de interface criada anteriormente. Isso restaura o escritório aconchegante, a Mika em destaque, sombras, plantas, laptop e botão rosa da composição.
- O botão Começar, embora pintado na arte de fundo, possui uma camada de botão HTML clicável e acessível na mesma posição.
- Chat, memória, conexão e projeto preservam a lógica da v0.3 e recebem cards em papel-creme, sombras, rosa-coral, molduras discretamente pixeladas e contraste melhorado.
- Versão Android atualizada para 0.4 (versionCode 4).

## Limitação reconhecida (não esconder)
Esta etapa prioriza a fidelidade da splash: os textos e o cenário da tela principal estão dentro de uma arte raster; portanto, não são individualmente refluídos nem traduzíveis. Futuramente devemos reconstruir o cenário em camadas separadas e sprites exportados individualmente, conservando acessibilidade e responsividade. O restante da interface usa HTML real e controles acessíveis. Não há motor offline ainda.

## Validação
Conferir em um celular real (Galaxy A14 5G, Android 14) se o botão rosa está alinhado, legibilidade, rolagem, navegação e restauração de memória; a renderização simulada com Chrome só verifica o front-end.

## Fonte da arte
`a_polished_pixel_art_character_sheet_ui_concept.png`, conceito visual aprovado pelo usuário nesta conversa. A personagem 8-bit continua **experimental**, enquanto a prancha canônica é `Mika - Marketing.png` no Drive.

## Instalação em paralelo
A v0.4 usa `br.mvz.mika.preview` e o nome `Mika Pixel HD (Teste)`, para instalar ao lado da antiga sem conflito de assinatura e sem remover memórias. É um build de comparação; não realiza migração automática de histórico.
