# Mika Android v0.8 — Pixel HD + primeiro cérebro local

Baseado na v0.7 aprovada no Galaxy A14. Preserva splash clássica, animações, sprites e memória controlada pelo usuário.

**Novo nesta versão:** suporte efetivo ao `llama-server` local (Termux), via loopback 127.0.0.1:8080 e API OpenAI-compatible `/v1/chat/completions`, além do Ollama remoto já existente. A simulação não é confundida com IA real.

A inferência **não está embutida no APK**: ela roda em um processo Termux separado, sem nuvem. Veja `INSTALAR_MODELO_NO_CELULAR.md`.

O ZIP não contém o arquivo de pesos GGUF para manter o APK pequeno.

Compilação no GitHub usando o workflow `compilar-mika-v08.yml`. Não substitui a v0.7, package ID distinto.

Testes locais: sintaxe JS; integridade de assets; testes de endpoints com servidor fictício; interface em navegador; **ainda não validado no aparelho físico**.
